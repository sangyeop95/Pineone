package com.example.mypage;

public interface OnDialogClickListener {

    void onClickConfirmButton();
}

package com.example.mypage;

import android.view.View;

public interface OnItemClickListener {

    void onItemClick(View v, boolean isSelect);
}
